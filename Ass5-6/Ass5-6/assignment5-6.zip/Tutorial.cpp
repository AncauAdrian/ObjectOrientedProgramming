#include "Tutorial.h"
#include <assert.h>
#include <string>
#include <iostream>


Tutorial::Tutorial()
{
	this->title = std::string("None");
	this->author = std::string("None");
	this->likes = 0;
	this->duration = 0;
	this->link = std::string("None");
}

Tutorial::Tutorial(std::string title, std::string author, int likes, int duration, std::string link)
{
	this->title = title;
	this->author = author;
	this->likes = likes;
	this->duration = duration;
	this->link = link;
}

std::string Tutorial::getTitle()
{
	return this->title;
}

std::string Tutorial::getAuthor()
{
	return this->author;
}

int Tutorial::getLikes()
{
	return this->likes;
}

int Tutorial::getDuration()
{
	return this->duration;
}

std::string Tutorial::getLink()
{
	return this->link;
}

std::string Tutorial::prettyfy()
{
	return std::string("Title: " + this->title + "  Author: " + this->author + "  Duration: " +
		std::to_string(this->duration / 60) + ":" + std::to_string(this->duration % 60) + "  Likes: " + std::to_string(this->likes) + "  Link: " + this->link);
}

void testTutorial()
{
	Tutorial t(std::string("Test"), std::string("Me"), 123, 70, std::string("https://www.fuckyou.com"));
	assert(t.getTitle().compare("Test") == 0);
	assert(t.getAuthor().compare("Me") == 0);
	assert(t.getLikes() == 123);
	assert(t.getDuration() == 70);
	assert(t.getLink().compare("https://www.fuckyou.com") == 0);
	assert(t.prettyfy().compare("Title: Test  Author: Me  Duration: 1:10  Likes: 123  Link: https://www.fuckyou.com") == 0);
}
