#include "Controller.h"
#include <string>
#include <iostream>
#include <assert.h>

Controller::Controller(Repository & r) : repo(r)
{
}

void Controller::process_input(DynamicVector<std::string>& args)
{
	if (args.getSize() == 0)
		throw "[ERROR] Invalid command!";

	if (args[0].compare("add") == 0 && args.getSize() == 6)
	{
		try
		{
			int likes, minutes, seconds;
			likes = std::stoi(args[4]);
			int index = args[3].find(':');
			if (index == std::string::npos)
				throw "";

			minutes = std::stoi(args[3].substr(0, index));
			seconds = std::stoi(args[3].substr(index + 1, args[3].length()));

			if (likes < 0 || minutes < 0 || seconds < 0)
				throw "";

			
			this->add(args[1], args[2], likes, minutes, seconds, args[5]);
		}
		catch (...)
		{
			throw "[ERROR] Invalid arguments enterred!";
		}
	}
	else if (args[0].compare("update") == 0 && args.getSize() == 6)
	{
		try
		{
			int likes, minutes, seconds;
			likes = std::stoi(args[4]);
			int index = args[3].find(':');
			if (index == std::string::npos)
				throw "";

			minutes = std::stoi(args[3].substr(0, index));
			seconds = std::stoi(args[3].substr(index + 1, args[3].length()));

			if (likes < 0 || minutes < 0 || seconds < 0)
				throw "";

			this->update(args[1], args[2], likes, minutes, seconds, args[5]);
		}
		catch (...)
		{
			throw "[ERROR] Invalid arguments enterred!";
		}
	}
	else if (args[0].compare("remove") == 0 && args.getSize() == 3)
	{
		try
		{
			this->remove(args[1], args[2]);
		}
		catch (...)
		{
			throw "[ERROR] Invalid arguments enterred!";
		}
	}
	else throw "[ERROR] Invalid command!";
}

void Controller::add(std::string title, std::string author, int likes, int minutes, int seconds, std::string link)
{
	Tutorial t(title, author, likes, minutes * 60 + seconds, link);

	int i = this->repo.find(t);

	if (i != -1)
		throw "[ERROR] Item already exists!";

	this->repo.add_tutorial(t);
}

void Controller::update(std::string title, std::string author, int likes, int minutes, int seconds, std::string link)
{
	Tutorial t(title, author, likes, minutes * 60 + seconds, link);

	int i = this->repo.find(t);

	if (i == -1)
		throw "[ERROR] Item doesn't exist!";

	this->repo.update_tutorial(t);
}

void Controller::remove(std::string title, std::string author)
{
	Tutorial t(title, author, 0, 0, "");

	int i = this->repo.find(t);

	if (i == -1)
		throw "[ERROR] Item doesn't exist!";

	this->repo.remove_tutorial(t);
}

Repository & Controller::getRepo()
{
	return this->repo;
}

void testController()
{
	Repository repo;
	Controller cont(repo);


	cont.add("TestT", "TestA", 100, 60, 23, "www");
	cont.add("TestT1", "TestA1", 101, 60, 24, "www1");
	cont.add("TestT2", "TestA2", 101, 60, 25, "www2");
	cont.add("TestT3", "TestA3", 101, 60, 26, "www3");

	cont.remove("TestT3", "TestA3");
	try
	{
		cont.remove("Test3", "TestA3");
	}
	catch (...)
	{
		assert(true);
	}

	DynamicVector<std::string> cmd;
	try
	{
		cont.process_input(cmd);
	}
	catch (...)
	{
		assert(true);
	}

	cmd.add(std::string("add"));
	cmd.add(std::string("Test"));
	cmd.add(std::string("Test"));
	cmd.add(std::string("10:15"));
	cmd.add(std::string("222"));
	try
	{
		cont.process_input(cmd);
	}
	catch (...)
	{
		assert(true);
	}

	cmd.add(std::string("www"));
	cont.process_input(cmd);

	DynamicVector<std::string> a;
	cmd = a;

	cmd.add(std::string("update"));
	cmd.add(std::string("Test"));
	cmd.add(std::string("Test"));
	cmd.add(std::string("10:5"));
	cmd.add(std::string("1111"));
	cmd.add(std::string("wwww"));
	cont.process_input(cmd);

	cmd = a;

	cmd.add(std::string("remove"));

	cont.getRepo();
	try
	{
		cont.process_input(cmd);
	}
	catch (...)
	{
		assert(true);
	}
	cmd.add(std::string("Test"));
	try
	{
		cont.process_input(cmd);
	}
	catch (...)
	{
		assert(true);
	}
	cmd.add(std::string("Test"));
	cont.process_input(cmd);

	try {
		cont.add("TestT", "TestA", 100, 60, 23, "www");
	}
	catch (...)
	{
		assert(true);
	}
	
}
