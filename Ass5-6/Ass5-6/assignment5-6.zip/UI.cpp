#include "DynamicVector.h"
#include "Tutorial.h"
#include "Repository.h"
#include "Controller.h"
#include "WachlistController.h"
#include "UI.h"
#include <string>
#include <iostream>
#include <exception>

void UI::showmenu_admin()
{
	std::cout << "\n\n>>>> ADMINISTRATOR MODE <<<<" << std::endl;
	std::cout << "add <title> <author> <duration(mm:ss)> <likes> <link>" << std::endl;
	std::cout << "update <title> <author> <duration(mm:ss)> <likes> <link>" << std::endl;
	std::cout << "remove <title> <author>" << std::endl;
	std::cout << "list" << std::endl;
	std::cout << "usermode" << std::endl;
	std::cout << "exit" << std::endl;
}

void UI::showmenu_user()
{
	std::cout << "\n\n>>>>>>>>> USER MODE <<<<<<<<" << std::endl;
	std::cout << "list -- list the entire watchlist" << std::endl;
	std::cout << "start <author=""> -- iterate over the tutorials that have the specified author" << std::endl;
	std::cout << "add -- while iterating, add the current tutorial to the watchlist" << std::endl;
	std::cout << "next -- while iterating, skip to the next tutorial" << std::endl;
	std::cout << "delete <index>" << std::endl;
	std::cout << "exit -- if iterating exit to usermode, if in usermode exit to admin mode" << std::endl;
}

void UI::initialise(Controller& cont)
{
	cont.add("Types", "Adrian", 11, 12, 7, "https://www.youtube.com/watch?v=dUUap90oiPA");
	cont.add("Functions", "Dan", 151, 22, 5, "https://www.youtube.com/watch?v=dUUap90oiPA");
	cont.add("Classes", "Adrian", 51, 3, 11, "https://www.youtube.com/watch?v=dUUap90oiPA");
	cont.add("Templates", "Adrian", 111, 13, 27, "https://www.youtube.com/watch?v=dUUap90oiPA");
	cont.add("Pointers", "Dan", 121, 5, 35, "https://www.youtube.com/watch?v=dUUap90oiPA");
	cont.add("Libraries", "Dan", 12, 12, 59, "https://www.youtube.com/watch?v=dUUap90oiPA");
	cont.add("GeneralKnowledge", "Adrian", 205, 18, 33, "https://www.youtube.com/watch?v=dUUap90oiPA");
	cont.add("Miscellanious", "Alex", 113, 25, 25, "https://www.youtube.com/watch?v=dUUap90oiPA");
	cont.add("Includes", "Alex", 341, 11, 53, "https://www.youtube.com/watch?v=dUUap90oiPA");
	cont.add("Scopes", "Alex", 123, 12, 5, "https://www.youtube.com/watch?v=dUUap90oiPA");
}

void UI::admin()
{
	UI::showmenu_admin();

	Repository repo;
	Repository Wrepo;
	Controller cont(repo);
	UI::initialise(cont);

	while (true)
	{
		DynamicVector<std::string> arg;

		std::string s;
		std::cout << "admin >>";
		std::getline(std::cin, s);

		std::string delimiter = " ";

		size_t pos = 0;
		std::string token;
		while ((pos = s.find(delimiter)) != std::string::npos)
		{
			token = s.substr(0, pos);
			arg.add(token);
			s.erase(0, pos + delimiter.length());
		}
		token = s.substr(0, pos);
		arg.add(token);

		if (arg[0].compare("exit") == 0)
			break;

		if (arg[0].compare("list") == 0)
		{
			std::cout << cont.getRepo().pretty_print();
			continue;
		}

		if (arg[0].compare("usermode") == 0)
		{
			UI::user(repo, Wrepo);
			continue;
		}

		try
		{
			cont.process_input(arg);
		}
		catch (...)
		{
			std::cout << "Exception occured\n";
		}
	}
}

void UI::user(Repository & repo, Repository & Wrepo)
{

	UI::showmenu_user();

	Repository temp;
	WachlistController cont(repo, Wrepo);

	while (true)
	{
		DynamicVector<std::string> arg;

		std::string s;
		std::cout << "usermode >>";
		std::getline(std::cin, s);

		std::string delimiter = " ";

		size_t pos = 0;
		std::string token;
		while ((pos = s.find(delimiter)) != std::string::npos)
		{
			token = s.substr(0, pos);
			arg.add(token);
			s.erase(0, pos + delimiter.length());
		}
		token = s.substr(0, pos);
		arg.add(token);

		if (arg[0].compare("exit") == 0)
			break;

		if (arg[0].compare("help") == 0)
		{
			UI::showmenu_user();
			continue;
		}

		if (arg[0].compare("list") == 0)
		{
			std::cout << Wrepo.pretty_print();
			continue;
		}
		try
		{
			cont.process_input(arg);
		}
		catch (...)
		{
			std::cout << "Exception occured\n";
		}
	}
}
