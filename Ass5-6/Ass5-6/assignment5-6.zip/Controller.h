#pragma once
#include "Repository.h"
#include "DynamicVector.h"

class Controller
{
	Repository & repo;
public:
	Controller(Repository & r);

	void process_input(DynamicVector<std::string> &args);

	void add(std::string title, std::string author, int likes, int minutes, int seconds, std::string link);

	void update(std::string title, std::string author, int likes, int minutes, int seconds, std::string link);

	void remove(std::string title, std::string author);

	Repository& getRepo();
};

void testController();