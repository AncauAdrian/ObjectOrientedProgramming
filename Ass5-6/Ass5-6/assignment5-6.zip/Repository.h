#pragma once
#include "Tutorial.h"
#include "DynamicVector.h"

class Repository
{
	DynamicVector<Tutorial> v;
public:
	// Adds a new tutorial to the vector
	void add_tutorial(Tutorial t);

	// Finds a tutorial and returns it's index, a tutorial's uniqueness is determined by the Title and Author
	int find(Tutorial t);

	// Removes the tutorial from the list, a tutorial's uniqueness is determined by the Title and Author
	void remove_tutorial(Tutorial &t);

	void remove_tutorial(int index);

	// Update a specific tutorial from the list, a tutorial's uniqueness is determined by the Title and Author
	void update_tutorial(Tutorial t);

	// Returns a string from the repo
	std::string pretty_print();

	// Returns a repo of tutorials that have the author
	Repository search_a(std::string author);

	bool isEmpty();

	int getLength();

	Repository& operator=(const Repository & r);

	Tutorial& operator[](const int index);
};


void testRepository();
