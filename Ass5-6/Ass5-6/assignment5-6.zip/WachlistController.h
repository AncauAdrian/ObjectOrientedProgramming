#pragma once
#include "Repository.h"
#include "DynamicVector.h"
#include <string>

class WachlistController
{
	Repository temp;
	Repository & repo;
	Repository & Wrepo;
public:
	WachlistController(Repository & r, Repository & wr);
	void process_input(DynamicVector<std::string> & args);
	void start_iterating(Repository & repo);
	void add_watchlist(Tutorial t);
	void remove(int index);

};

void testWatchlistController();
