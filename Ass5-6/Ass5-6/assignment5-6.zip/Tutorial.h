#pragma once
#include <string>

class Tutorial
{
	std::string title;
	std::string author;
	int likes;
	int duration;
	std::string link;

public:

	// Default constructor
	Tutorial();

	Tutorial(std::string title, std::string author, int likes, int duration, std::string link);
	
	std::string getTitle();
	std::string getAuthor();
	int getLikes();
	int getDuration();
	std::string getLink();

	// Returns a printable string of the Tutorial
	std::string prettyfy();
};

void testTutorial();
