#include "Repository.h"
#include "DynamicVector.h"
#include "Tutorial.h"

void Repository::add_tutorial(Tutorial t)
{
	this->v.add(t);
}

int Repository::find(Tutorial t)
{
	for (int i = 0; i < this->v.getSize(); i++)
	{
		Tutorial a = this->v[i];
		if (this->v[i].getTitle().compare(t.getTitle()) == 0 && this->v[i].getAuthor().compare(t.getAuthor()) == 0)
			return i;
	}
	return -1;
}

void Repository::remove_tutorial(Tutorial &t)
{
	int index = this->find(t);
	if (index == -1)
		throw "[ERROR] Could not find the tutorial!";

	v.remove(index);
}

void Repository::remove_tutorial(int index)
{
	v.remove(index);
}

void Repository::update_tutorial(Tutorial t)
{
	int index = this->find(t);
	if (index == -1)
		throw "[ERROR] Could not find the tutorial!";

	v[index] = t;
}

std::string Repository::pretty_print()
{
	std::string s;
	for (int i = 0; i < this->v.getSize(); i++)
	{
		s += std::to_string(i) + ": " + v[i].prettyfy() + '\n';
	}
	return s;
}

Repository Repository::search_a(std::string author)
{
	Repository temp;
	for (int i = 0; i < this->getLength(); i++)
	{
		if (this->v[i].getAuthor().find(author) != std::string::npos) {
			temp.add_tutorial(this->v[i]);
		}
	}

	return temp;
}

bool Repository::isEmpty()
{
	if (this->v.getSize() == 0)
		return true;
	return false;
}

int Repository::getLength()
{
	return this->v.getSize();
}

Repository & Repository::operator=(const Repository & r)
{
	this->v = r.v;
	return *this;
}

Tutorial & Repository::operator[](const int index)
{
	return this->v[index];
}

void testRepository()
{
	Repository repo;
	Tutorial t1{ "TEst1", "Me1", 101, 61, "www1" };
	Tutorial t2{ "TEst2", "Me2", 102, 62, "www2" };
	Tutorial t3{ "TEst3", "Me3", 103, 63, "www3" };
	Tutorial t4{ "TEst4", "Me4", 104, 64, "www4" };

	repo.add_tutorial(t1);
	repo.add_tutorial(t2);
	repo.add_tutorial(t3);
	repo.add_tutorial(t4);
	repo[3];
	assert(repo.find(t1) == 0);
	assert(repo.find(t2) == 1);
	assert(repo.find(t3) == 2);
	assert(repo.find(t4) == 3);
	repo.remove_tutorial(t2);
	Tutorial t("TEst23123", "Me1", 101, 61, "www1");
	try
	{
		repo.remove_tutorial(t);
	}
	catch (...)
	{
		assert(true);
	}
	assert(repo.find(t1) == 0);
	assert(repo.find(t3) == 1);
	assert(repo.find(t4) == 2);
	repo.remove_tutorial(2);
	Tutorial t5{ "TEst3", "Me3", 104, 64, "www3" };
	repo.update_tutorial(t5);
	repo.remove_tutorial(0);
	repo.remove_tutorial(0);
	
	Repository newrepo;
	repo = newrepo;
	assert(repo.isEmpty());
	assert(repo.getLength() == 0);

	Tutorial tt{ "Test", "Test", 100, 64, "www" };
	repo.add_tutorial(tt);
	assert(!repo.isEmpty());
	assert(repo.getLength() == 1);
	repo.pretty_print();
	repo.search_a("Test");
	repo.search_a("Tesasdadst");

	try
	{
		repo.update_tutorial(t1);
	}
	catch (...)
	{
		assert(true);
	}
}
