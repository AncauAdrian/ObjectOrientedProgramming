#include "DynamicVector.h"
#include <assert.h>


template <typename T>
DynamicVector<T>::DynamicVector(int capacity)
{
	if (capacity <= 0)
		throw "[ERROR] Invalid capacity!";

	this->capacity = 32;
	this->size = 0;
	
	this->elems = new T[capacity];
}

template <typename T>
DynamicVector<T>::DynamicVector(const DynamicVector<T> &v)
{
	this->capacity = v.capacity;
	this->size = v.size;

	this->elems = new T[this->capacity];

	for (int i = 0; i < v.size; i++)
		this->elems[i] = v.elems[i];
}

template <typename T>
DynamicVector<T>::~DynamicVector()
{
	delete[] this->elems;
}

template <typename T>
DynamicVector<T>& DynamicVector<T>::operator=(const DynamicVector<T>& v)
{
	if (this == &v)
		return *this;

	this->size = v.size;
	this->capacity = v.capacity;

	T *aux = new T[this->capacity];

	delete[] this->elems;

	this->elems = aux;
	for (int i = 0; i < this->size; i++)
		this->elems[i] = v.elems[i];

	return *this;
}

template <typename T>
T& DynamicVector<T>::operator[](int pos)
{
	return this->elems[pos];
}

template <typename T>
void DynamicVector<T>::resize(int factor)
{
	if (factor <= 1)
		throw "[ERROR] Cannot resize a vector by a factor or 1 or less";

	this->capacity *= factor;

	T* els = new T[this->capacity];
	for (int i = 0; i < this->size; i++)
		els[i] = this->elems[i];

	delete[] this->elems;
	this->elems = els;
}

template <typename T>
void DynamicVector<T>::add(T e)
{
	if (this->size == this->capacity)
		this->resize();

	this->elems[this->size] = e;
	this->size++;
}

template <typename T>
void DynamicVector<T>::remove(int index)
{
	for (int i = index; i < this->size - 1; i++)
		this->elems[i] = this->elems[i + 1];
	
	this->size--;
}

template <typename T>
int DynamicVector<T>::getSize() const
{
	return this->size;
}


void testDynamicArray()
{
	DynamicVector<int> test(32);
	test.add(1);
	test.add(2);
	test.add(3);
	test.add(4);
	assert(test.getSize() == 4);
	assert(test[0] == 1);
	assert(test[1] == 2);
	assert(test[2] == 3);
	assert(test[3] == 4);

	DynamicVector<int> second(test);
	assert(second.getSize() == 4);
	assert(second[0] == 1);
	assert(second[1] == 2);
	assert(second[2] == 3);
	assert(second[3] == 4);

	test.remove(0);
	assert(test.getSize() == 3);
	assert(test[0] == 2);
	assert(second.getSize() == 4);
}