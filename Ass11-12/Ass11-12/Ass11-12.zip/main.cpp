#include "Ass1112.h"
#include "UI.h"


int main(int argc, char *argv[])
{
	int ret = UI::admin(argc, argv);
	return ret;
}
