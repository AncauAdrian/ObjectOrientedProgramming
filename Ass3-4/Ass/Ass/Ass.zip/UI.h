#pragma once

/// <summary>
///	Show Menu
/// </summary>
/// <param name="capacity">None</param>
/// <returns>None</returns>
void show_menu();
void start();