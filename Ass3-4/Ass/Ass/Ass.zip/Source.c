#include <stdio.h>
#include "UI.h"


int main(int argv, int **argc)
{
	start();
	return 0;
}