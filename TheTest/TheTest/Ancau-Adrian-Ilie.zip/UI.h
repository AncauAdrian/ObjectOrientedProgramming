#pragma once
#include "Repository.h"

class UI
{
public:
	static void initialise(Repository & repo);

	static void showmenu();
	static void start();
};

